import flet as ft
from flet import Colors, Icons
import random
import threading
import time
from fractions import Fraction
import math
import sys
import os

# تنظیم مسیر برای فایل‌های اجرایی
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# -------------------------
# راه‌اندازی صدا
# -------------------------
def init_audio():
    """راه‌اندازی سیستم صدا"""
    try:
        pygame.mixer.init()
        return True
    except:
        return False


# ایجاد صداهای ساده
def create_sounds():
    """ایجاد صداهای ساده برای بازی"""
    sounds = {}
    try:
        # صداهای مختلف برای رویدادهای بازی
        sounds['correct'] = None  # می‌توانید فایل صوتی اضافه کنید
        sounds['wrong'] = None  # می‌توانید فایل صوتی اضافه کنید
        sounds['dice'] = None  # می‌توانید فایل صوتی اضافه کنید
        sounds['win'] = None  # می‌توانید فایل صوتی اضافه کنید
        sounds['move'] = None  # می‌توانید فایل صوتی اضافه کنید
    except:
        pass
    return sounds


# -------------------------
# کمک‌افزارها
# -------------------------
def frac_str(x):
    """دریافت رشته‌ای از عدد کسری یا عدد صحیح به شکل 'a/b'"""
    if isinstance(x, Fraction):
        return str(x)
    try:
        f = Fraction(x).limit_denominator()
        return str(f)
    except Exception:
        return str(x)


def normalize_answer(ans: str):
    """نرمال‌سازی پاسخ کاربر به قالب کسری"""
    ans = ans.strip()
    if ans == "":
        return ans
    try:
        if "/" in ans:
            return str(Fraction(ans).limit_denominator())
        else:
            return str(Fraction(float(ans)).limit_denominator())
    except Exception:
        return ans


# -------------------------
# بانک سؤال‌ها برای بازی مرحله‌ای و مارپله
# -------------------------
def build_question_bank():
    bank = []

    # سطح 1: بسیار ساده (10 سوال)
    level1_questions = [
        lambda: ("یک سکه پرتاب می کنیم. احتمال پشت؟", "1/2"),
        lambda: ("یک سکه پرتاب می کنیم. احتمال رو؟", "1/2"),
        lambda: ("یک تاس می اندازیم. احتمال عدد 1؟", "1/6"),
        lambda: ("یک تاس می اندازیم. احتمال عدد 6؟", "1/6"),
        lambda: ("یک تاس می اندازیم. احتمال عدد زوج؟", "1/2"),
        lambda: ("یک تاس می اندازیم. احتمال عدد فرد؟", "1/2"),
        lambda: ("یک تاس می اندازیم. احتمال عدد بزرگتر از 4؟", "1/3"),
        lambda: ("کیسه ای با 3 توپ قرمز و 2 آبی. احتمال کشیدن قرمز؟", "3/5"),
        lambda: ("کیسه ای با 4 توپ سبز و 1 زرد. احتمال کشیدن سبز؟", "4/5"),
        lambda: ("کیسه ای با 2 سفید و 3 سیاه. احتمال کشیدن سفید؟", "2/5")
    ]

    for q in level1_questions:
        bank.append({"level": 1, "func": q})

    # سطح 2: متوسط (10 سوال - بدون جایگزینی)
    level2_questions = [
        lambda: ("دو سکه پرتاب می کنیم. احتمال هر دو پشت؟", "1/4"),
        lambda: ("دو سکه پرتاب می کنیم. احتمال دقیقاً یک پشت؟", "1/2"),
        lambda: ("دو سکه پرتاب می کنیم. احتمال حداقل یک پشت؟", "3/4"),
        lambda: ("دو سکه پرتاب می کنیم. احتمال هیچ پشتی؟", "1/4"),
        lambda: ("دو تاس می اندازیم. احتمال مجموع 7؟", "1/6"),
        lambda: ("دو تاس می اندازیم. احتمال مجموع کمتر از 5؟", "1/6"),
        lambda: ("دو تاس می اندازیم. احتمال هر دو عدد یکسان؟", "1/6"),
        lambda: ("دو تاس می اندازیم. احتمال یکی زوج و یکی فرد؟", "1/2"),
        lambda: ("کیسه ای با 3 قرمز و 2 آبی. یک توپ می کشیم. احتمال آبی؟", "2/5"),
        lambda: ("کیسه ای با 5 سبز و 3 زرد. یک توپ می کشیم. احتمال زرد؟", "3/8")
    ]

    for q in level2_questions:
        bank.append({"level": 2, "func": q})

    return bank


# -------------------------
# بازی مارپله (بازی سوم)
# -------------------------
def snake_ladder_game(page: ft.Page):
    # پاک کردن کامل صفحه و ایجاد صفحه جدید
    page.clean()
    page.title = "🐍 مارپله احتمال"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.theme_mode = page.theme_mode  # حفظ حالت تاریک/روشن
    page.padding = 20

    # وضعیت بازی
    current_position = ft.Ref()
    dice_value = ft.Ref()
    game_over = ft.Ref()
    question_bank = ft.Ref()
    current_question = ft.Ref()
    current_answer = ft.Ref()

    current_position.current = 1
    dice_value.current = 0
    game_over.current = False
    question_bank.current = build_question_bank()
    current_question.current = ""
    current_answer.current = ""

    # تعریف مارها و نردبان‌ها
    snakes = {
        16: 6, 47: 26, 49: 11, 56: 53, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 98: 78
    }

    ladders = {
        1: 38, 4: 14, 9: 31, 21: 42, 28: 84, 36: 44, 51: 67, 71: 91, 80: 100
    }

    # المان‌های UI
    board_grid = ft.GridView(
        expand=1,
        runs_count=10,
        max_extent=50,
        child_aspect_ratio=1.0,
        spacing=5,
        run_spacing=5,
    )

    dice_text = ft.Text(
        size=24,
        weight=ft.FontWeight.BOLD,
        color=ft.Colors.BLUE_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_200
    )

    position_text = ft.Text(
        size=20,
        weight=ft.FontWeight.BOLD,
        color=ft.Colors.GREEN_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREEN_200
    )

    status_text = ft.Text(
        size=18,
        text_align=ft.TextAlign.CENTER,
        color=ft.Colors.BROWN_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BROWN_200
    )

    question_text = ft.Text(
        size=16,
        text_align=ft.TextAlign.CENTER,
        color=ft.Colors.BLUE_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_200,
        weight=ft.FontWeight.BOLD
    )

    answer_input = ft.TextField(
        label="پاسخ (مثلاً 1/2 یا 0.5)",
        width=200,
        text_align=ft.TextAlign.CENTER
    )

    roll_dice_btn = ft.ElevatedButton(
        "🎲 تاس بینداز",
        on_click=lambda e: roll_dice(),
        bgcolor=ft.Colors.ORANGE_600,
        color=ft.Colors.WHITE,
        icon=Icons.CASINO
    )

    submit_answer_btn = ft.ElevatedButton(
        "✅ پاسخ بده",
        on_click=lambda e: check_answer(),
        bgcolor=ft.Colors.BLUE_600,
        color=ft.Colors.WHITE,
        icon=Icons.CHECK
    )

    back_btn = ft.ElevatedButton(
        "🔙 بازگشت به منو",
        on_click=lambda e: main_menu(page),
        bgcolor=ft.Colors.RED_600,
        color=ft.Colors.WHITE,
        icon=Icons.ARROW_BACK
    )

    new_game_btn = ft.ElevatedButton(
        "🔄 بازی جدید",
        on_click=lambda e: start_new_game(),
        bgcolor=ft.Colors.GREEN_600,
        color=ft.Colors.WHITE,
        icon=Icons.REPLAY
    )

    # تابع ایجاد صفحه بازی
    def create_board():
        board_grid.controls.clear()
        for i in range(100, 0, -1):
            # تعیین رنگ خانه‌ها بر اساس حالت تاریک/روشن
            if page.theme_mode == ft.ThemeMode.LIGHT:
                default_color = ft.Colors.WHITE
                snake_color = ft.Colors.RED_100
                ladder_color = ft.Colors.GREEN_100
                player_color = ft.Colors.YELLOW_200
                final_color = ft.Colors.PURPLE_200  # رنگ خانه نهایی
                border_color = ft.Colors.GREY_400
            else:
                default_color = ft.Colors.GREY_900
                snake_color = ft.Colors.RED_900
                ladder_color = ft.Colors.GREEN_900
                player_color = ft.Colors.YELLOW_800
                final_color = ft.Colors.PURPLE_800  # رنگ خانه نهایی
                border_color = ft.Colors.GREY_600

            cell_color = default_color
            if i == 100:  # خانه نهایی
                cell_color = final_color
            elif i in snakes:
                cell_color = snake_color
            elif i in ladders:
                cell_color = ladder_color
            elif i == current_position.current:
                cell_color = player_color

            cell_content = [
                ft.Text(str(i), size=10, weight=ft.FontWeight.BOLD,
                        color=ft.Colors.BLACK if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.WHITE),
            ]

            # اضافه کردن نمادها
            if i == 100:
                cell_content.append(ft.Text("🏁", size=12))  # نماد پایان
            elif i in snakes:
                cell_content.append(ft.Text("🐍", size=12))
            elif i in ladders:
                cell_content.append(ft.Text("🪜", size=12))
            elif i == current_position.current:
                cell_content.append(ft.Text("👤", size=12))

            cell = ft.Container(
                content=ft.Column(cell_content, spacing=0, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                width=45,
                height=45,
                bgcolor=cell_color,
                border=ft.border.all(1, border_color),
                border_radius=5,
                alignment=ft.alignment.center,
            )
            board_grid.controls.append(cell)

    # تابع پرتاب تاس
    def roll_dice():
        if game_over.current:
            return

        dice_value.current = random.randint(1, 6)
        dice_text.value = f"تاس: {dice_value.current}"
        status_text.value = f"تاس انداختی و عدد {dice_value.current} آمد!"
        status_text.color = ft.Colors.BLUE_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_300

        # انتخاب سوال تصادفی
        question_data = random.choice(question_bank.current)
        current_question.current, current_answer.current = question_data["func"]()
        question_text.value = f"سوال: {current_question.current}"

        answer_input.value = ""
        answer_input.visible = True
        submit_answer_btn.visible = True
        roll_dice_btn.visible = False

        page.update()

    # تابع بررسی پاسخ
    def check_answer():
        user_answer = normalize_answer(answer_input.value.strip())

        if user_answer == current_answer.current:
            # پاسخ درست - حرکت به جلو
            new_position = min(current_position.current + dice_value.current + 2, 100)  # 2 خانه پاداش
            status_text.value = f"🎉 درست جواب دادی! ۲ خانه جلو می‌روی!"
            status_text.color = ft.Colors.GREEN_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREEN_300
        else:
            # پاسخ اشتباه - حرکت به عقب
            new_position = max(current_position.current + dice_value.current - 2, 1)  # 2 خانه جریمه
            status_text.value = f"❌ اشتباه جواب دادی! ۲ خانه عقب می‌روی! پاسخ صحیح: {current_answer.current}"
            status_text.color = ft.Colors.RED_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.RED_300

        # بررسی مار یا نردبان
        if new_position in snakes:
            old_position = new_position
            new_position = snakes[new_position]
            status_text.value += f"\n🐍 اوه! به مار خوردی! از خانه {old_position} به خانه {new_position} سقوط کردی!"
        elif new_position in ladders:
            old_position = new_position
            new_position = ladders[new_position]
            status_text.value += f"\n🪜 آفرین! نردبان پیدا کردی! از خانه {old_position} به خانه {new_position} صعود کردی!"

        current_position.current = new_position
        position_text.value = f"خانه فعلی: {current_position.current}"

        # بررسی پایان بازی
        if current_position.current == 100:
            game_over.current = True
            status_text.value = "🎊 🎊 🎊 تبریک! برنده شدی! 🎊 🎊 🎊"
            status_text.color = ft.Colors.PURPLE_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.PURPLE_300
            roll_dice_btn.visible = False
            submit_answer_btn.visible = False
            answer_input.visible = False

        answer_input.visible = False
        submit_answer_btn.visible = False
        roll_dice_btn.visible = True

        create_board()
        page.update()

    # تابع شروع بازی جدید
    def start_new_game():
        current_position.current = 1
        dice_value.current = 0
        game_over.current = False
        current_question.current = ""
        current_answer.current = ""

        dice_text.value = "تاس: 0"
        position_text.value = "خانه فعلی: 1"
        status_text.value = "برای شروع تاس بینداز!"
        status_text.color = ft.Colors.BROWN_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BROWN_300
        question_text.value = ""

        answer_input.visible = False
        submit_answer_btn.visible = False
        roll_dice_btn.visible = True

        create_board()
        page.update()

    # رابط کاربری اصلی
    game_container = ft.Container(
        content=ft.Column([
            ft.Text("🐍 مارپله احتمال", size=28, weight=ft.FontWeight.BOLD,
                    color=ft.Colors.GREEN_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREEN_200,
                    text_align=ft.TextAlign.CENTER),

            ft.Container(
                content=ft.Column([
                    position_text,
                    dice_text,
                    status_text
                ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=10,
                bgcolor=ft.Colors.WHITE if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREY_800,
                border_radius=10,
                margin=10
            ),

            ft.Container(
                content=board_grid,
                width=600,
                height=300,
                bgcolor=ft.Colors.BROWN_100 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BROWN_800,
                padding=10,
                border_radius=10
            ),

            ft.Container(
                content=ft.Column([
                    question_text,
                    ft.Row([answer_input, submit_answer_btn],
                           alignment=ft.MainAxisAlignment.CENTER, spacing=10),
                ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=10,
                bgcolor=ft.Colors.WHITE if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREY_800,
                border_radius=10,
                margin=10
            ),

            ft.Row([roll_dice_btn], alignment=ft.MainAxisAlignment.CENTER),

            ft.Row([new_game_btn, back_btn], alignment=ft.MainAxisAlignment.CENTER, spacing=20)

        ], spacing=15, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        padding=20
    )

    page.add(game_container)
    start_new_game()


# -------------------------
# بازی مرحله‌ای (بازی اول)
# -------------------------
def stage_game(page: ft.Page):
    # پاک کردن کامل صفحه و ایجاد صفحه جدید
    page.clean()
    page.title = "🎮 بازی مرحله‌ای احتمال"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.theme_mode = page.theme_mode  # حفظ حالت تاریک/روشن
    page.padding = 20
    page.scroll = ft.ScrollMode.ADAPTIVE

    # وضعیت بازی
    level = ft.Ref()
    score = ft.Ref()
    time_left = ft.Ref()
    correct_answer = ft.Ref()
    wrongs = ft.Ref()
    current_player = ft.Ref()
    timer_running = ft.Ref()
    players = ft.Ref()
    results = ft.Ref()
    max_time_for_level = ft.Ref()
    questions_answered = ft.Ref()

    level.current = 1
    score.current = 0
    time_left.current = 25
    wrongs.current = 0
    current_player.current = 0
    timer_running.current = False
    players.current = []
    results.current = {}
    max_time_for_level.current = 25
    questions_answered.current = 0

    # ساخت بانک سوال
    question_bank = build_question_bank()
    used_questions = set()

    # -----------------------------
    # گرفتن اسامی بازیکنان
    # -----------------------------
    name_fields = []

    def add_name_field(e=None):
        if len(name_fields) < 6:
            tf = ft.TextField(
                label=f"نام بازیکن {len(name_fields) + 1}",
                width=320,
                border_color=ft.Colors.BLUE_400
            )
            name_fields.append(tf)
            names_box.controls.append(
                ft.Container(
                    tf,
                    margin=ft.margin.only(bottom=10)
                )
            )
            page.update()

    def remove_name_field(e=None):
        if len(name_fields) > 1:
            name_fields.pop()
            names_box.controls.pop()
            page.update()

    names_box = ft.Column()
    info_add = ft.Text(
        "نام هر بازیکن را وارد کنید (حداقل یک نام):",
        size=16,
        color=ft.Colors.BLUE_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_200,
        weight=ft.FontWeight.BOLD
    )

    add_btn = ft.ElevatedButton(
        "➕ افزودن بازیکن",
        icon=Icons.PERSON_ADD,
        on_click=add_name_field,
        bgcolor=ft.Colors.BLUE_100 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_800,
        color=ft.Colors.BLUE_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_100
    )

    remove_btn = ft.ElevatedButton(
        "➖ حذف بازیکن",
        icon=Icons.REMOVE,
        on_click=remove_name_field,
        bgcolor=ft.Colors.RED_100 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.RED_800,
        color=ft.Colors.RED_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.RED_100
    )

    start_btn = ft.ElevatedButton(
        "🎮 شروع بازی",
        bgcolor=ft.Colors.GREEN_600,
        color=ft.Colors.WHITE,
        icon=Icons.PLAY_ARROW,
        style=ft.ButtonStyle(
            shape=ft.RoundedRectangleBorder(radius=10)
        )
    )

    back_btn = ft.ElevatedButton(
        "🔙 بازگشت به منو",
        on_click=lambda e: main_menu(page),
        bgcolor=ft.Colors.ORANGE_600,
        color=ft.Colors.WHITE,
        icon=Icons.ARROW_BACK
    )

    controls_start = ft.Card(
        content=ft.Container(
            ft.Column(
                [
                    info_add,
                    names_box,
                    ft.Row([add_btn, remove_btn], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Container(start_btn, margin=ft.margin.only(top=20)),
                    ft.Container(back_btn, margin=ft.margin.only(top=10))
                ],
                spacing=12,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=30,
            width=560,
        ),
        elevation=8,
        color=ft.Colors.WHITE if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREY_800,
    )

    # ---------------------
    # UI اصلی بازی مرحله‌ای
    # ---------------------
    question_text = ft.Text(
        size=20,
        text_align=ft.TextAlign.CENTER,
        color=ft.Colors.BLUE_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_200,
        weight=ft.FontWeight.BOLD,
        selectable=True
    )

    timer_text = ft.Text(size=18,
                         color=ft.Colors.RED_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.RED_300,
                         weight=ft.FontWeight.BOLD)
    score_text = ft.Text(size=18,
                         color=ft.Colors.GREEN_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREEN_300,
                         weight=ft.FontWeight.BOLD)
    wrongs_text = ft.Text(size=18,
                          color=ft.Colors.ORANGE_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.ORANGE_300,
                          weight=ft.FontWeight.BOLD)
    player_text = ft.Text(size=22,
                          color=ft.Colors.PURPLE_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.PURPLE_300,
                          weight=ft.FontWeight.BOLD)
    remaining_text = ft.Text(size=14,
                             color=ft.Colors.BLUE_600 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_400)
    level_text = ft.Text(size=14,
                         color=ft.Colors.BLUE_600 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_400)
    progress_text = ft.Text(size=14,
                            color=ft.Colors.BLUE_600 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_400)

    answer_input = ft.TextField(
        label="پاسخ (مثلاً 1/2 یا 0.5)",
        width=350,
        border_color=ft.Colors.BLUE_400,
        text_size=16,
        text_align=ft.TextAlign.CENTER
    )

    result_text = ft.Text(size=18, color=ft.Colors.BLACK if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.WHITE,
                          text_align=ft.TextAlign.CENTER)

    question_card = ft.Container(
        content=ft.Column([
            ft.Row([
                ft.Icon(Icons.QUESTION_ANSWER, color=ft.Colors.BLUE_600),
                ft.Text("سوال:", size=16,
                        color=ft.Colors.BLUE_600 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_400,
                        weight=ft.FontWeight.BOLD)
            ], spacing=10),
            ft.Container(question_text, padding=ft.padding.only(top=10, bottom=10)),
            ft.Divider(height=1, color=ft.Colors.BLUE_100),
            ft.Row([
                ft.Icon(Icons.ACCESS_TIME, color=ft.Colors.RED_600),
                timer_text,
                ft.VerticalDivider(width=20),
                level_text,
                ft.VerticalDivider(width=20),
                progress_text
            ], spacing=8, alignment=ft.MainAxisAlignment.CENTER)
        ], spacing=12),
        padding=20,
        width=650,
        border_radius=15,
        bgcolor=ft.Colors.WHITE if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREY_800,
        shadow=ft.BoxShadow(blur_radius=10,
                            color=ft.Colors.BLUE_100 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_900),
        border=ft.border.all(1, ft.Colors.BLUE_200 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_800)
    )

    time_bar = ft.ProgressBar(
        width=600,
        height=12,
        value=1.0,
        color=ft.Colors.BLUE_400,
        bgcolor=ft.Colors.BLUE_100 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_800
    )

    status_card = ft.Container(
        content=ft.Row(
            [
                ft.Column([
                    ft.Text("🎯 امتیاز", size=14,
                            color=ft.Colors.BLUE_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_300),
                    score_text
                ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                ft.Column([
                    ft.Text("👤 بازیکن", size=14,
                            color=ft.Colors.PURPLE_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.PURPLE_300),
                    player_text
                ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                ft.Column([
                    ft.Text("❌ اشتباه", size=14,
                            color=ft.Colors.ORANGE_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.ORANGE_300),
                    wrongs_text
                ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                ft.Column([
                    ft.Text("📊 پیشرفت", size=14,
                            color=ft.Colors.GREEN_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREEN_300),
                    remaining_text
                ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            ],
            alignment=ft.MainAxisAlignment.SPACE_AROUND,
        ),
        padding=15,
        width=650,
        border_radius=12,
        bgcolor=ft.Colors.WHITE if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREY_800,
        shadow=ft.BoxShadow(blur_radius=8,
                            color=ft.Colors.BLUE_100 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_900),
    )

    # ---------------------
    # توابع بازی مرحله‌ای
    # ---------------------
    def get_new_question():
        nonlocal question_bank, used_questions

        question_level = min(2, level.current)
        suitable_questions = [q for q in question_bank if q["level"] == question_level]

        if not suitable_questions:
            suitable_questions = [q for q in question_bank if q["level"] <= question_level]

        available_questions = []
        for q in suitable_questions:
            question_text, answer = q["func"]()
            if question_text not in used_questions:
                available_questions.append(q)

        if not available_questions:
            used_questions.clear()
            available_questions = suitable_questions

        if available_questions:
            selected = random.choice(available_questions)
            q, a = selected["func"]()
            used_questions.add(q)
            return q, a
        else:
            return "یک سکه پرتاب می کنیم. احتمال پشت آمدن؟", "1/2"

    def start_level():
        q, ans = get_new_question()
        correct_answer.current = ans

        question_text.value = q
        answer_input.value = ""
        result_text.value = ""

        base_time = 30 - level.current * 2
        max_time = max(15, base_time)
        max_time_for_level.current = max_time
        time_left.current = max_time
        time_bar.value = 1.0

        level_text.value = f"سطح: {level.current}"
        progress_text.value = f"سوال: {questions_answered.current + 1}/10"
        remaining_text.value = f"سوال: {questions_answered.current + 1}/10"

        timer_running.current = True
        page.update()

    def check_level_completion():
        if questions_answered.current >= 10:
            questions_answered.current = 0
            level.current += 1
            result_text.value = f"🎊 سطح {level.current - 1} تمام شد! به سطح {level.current} می‌روید..."
            result_text.color = ft.Colors.GREEN_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREEN_300
            page.update()
            time.sleep(2)
            start_level()
        else:
            start_level()

    def finish_player():
        name = players.current[current_player.current]
        results.current[name] = score.current

        result_text.value = f"❌ {name} حذف شد! امتیاز نهایی: {score.current}"
        page.update()
        time.sleep(2)

        current_player.current += 1

        if current_player.current >= len(players.current):
            show_final_results()
            return

        reset_for_new_player()

    def reset_for_new_player():
        score.current = 0
        wrongs.current = 0
        level.current = 1
        questions_answered.current = 0

        player_text.value = players.current[current_player.current]
        score_text.value = f"{score.current}"
        wrongs_text.value = f"{wrongs.current}/3"
        remaining_text.value = f"سوال: 0/10"

        page.update()
        time.sleep(1)
        start_level()

    def show_final_results():
        page.clean()

        sorted_res = sorted(results.current.items(), key=lambda x: x[1], reverse=True)

        result_items = []
        for i, (name, score_val) in enumerate(sorted_res):
            color = ft.Colors.GREEN_700 if i == 0 else ft.Colors.BLUE_700 if i == 1 else ft.Colors.ORANGE_700
            if page.theme_mode == ft.ThemeMode.DARK:
                color = ft.Colors.GREEN_300 if i == 0 else ft.Colors.BLUE_300 if i == 1 else ft.Colors.ORANGE_300
            icon = "🥇" if i == 0 else "🥈" if i == 1 else "🥉" if i == 2 else "🎯"
            result_items.append(
                ft.Container(
                    ft.Row([
                        ft.Text(icon, size=28),
                        ft.Text(f"{name}: {score_val} امتیاز", size=20, color=color, weight=ft.FontWeight.BOLD)
                    ], spacing=15),
                    padding=15,
                    bgcolor=ft.Colors.WHITE if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREY_800,
                    border_radius=10,
                    margin=5,
                    width=400
                )
            )

        page.add(
            ft.Column(
                [
                    ft.Text("🏆 نتایج نهایی بازی", size=28,
                            color=ft.Colors.BLUE_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_200,
                            weight=ft.FontWeight.BOLD),
                    ft.Container(
                        ft.Column(result_items, spacing=8, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                        padding=20
                    ),
                    ft.Row([
                        ft.ElevatedButton(
                            "🔄 بازی مجدد",
                            on_click=lambda e: stage_game(page),
                            bgcolor=ft.Colors.GREEN_600,
                            color=ft.Colors.WHITE,
                            icon=Icons.REPLAY
                        ),
                        ft.ElevatedButton(
                            "🔙 منوی اصلی",
                            on_click=lambda e: main_menu(page),
                            bgcolor=ft.Colors.BLUE_600,
                            color=ft.Colors.WHITE,
                            icon=Icons.HOME
                        )
                    ], spacing=20, alignment=ft.MainAxisAlignment.CENTER)
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=20,
            )
        )

    def check_answer(e=None):
        if not timer_running.current:
            return

        user_ans = normalize_answer(answer_input.value.strip())

        if user_ans == correct_answer.current:
            result_text.value = "🎉 درست جواب دادی! +10 امتیاز"
            result_text.color = ft.Colors.GREEN_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREEN_300
            score.current += 10
            questions_answered.current += 1

            score_text.value = f"{score.current}"
            remaining_text.value = f"سوال: {questions_answered.current}/10"
            page.update()
            time.sleep(0.8)
        else:
            wrongs.current += 1
            result_text.value = f"❌ پاسخ صحیح: {correct_answer.current}"
            result_text.color = ft.Colors.RED_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.RED_300

            if wrongs.current >= 3:
                wrongs_text.value = f"{wrongs.current}/3"
                page.update()
                time.sleep(1)
                finish_player()
                return

        score_text.value = f"{score.current}"
        wrongs_text.value = f"{wrongs.current}/3"

        timer_running.current = False
        page.update()
        time.sleep(1.2)
        check_level_completion()

    def run_timer():
        while True:
            if timer_running.current:
                if time_left.current > 0:
                    time_left.current -= 1
                    try:
                        time_bar.value = time_left.current / max(1, max_time_for_level.current)
                    except Exception:
                        time_bar.value = 0
                    timer_text.value = f"{time_left.current} ثانیه"
                    page.update()
                    time.sleep(1)
                else:
                    timer_running.current = False
                    result_text.value = f"⏰ زمان تمام شد! پاسخ: {correct_answer.current}"
                    result_text.color = ft.Colors.ORANGE_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.ORANGE_300
                    wrongs.current += 1
                    wrongs_text.value = f"{wrongs.current}/3"
                    page.update()
                    time.sleep(2)

                    if wrongs.current >= 3:
                        finish_player()
                    else:
                        questions_answered.current += 1
                        check_level_completion()
            else:
                time.sleep(0.1)

    answer_input.on_submit = check_answer

    def start_game(e):
        collected = [t.value.strip() for t in name_fields if t.value.strip()]

        if len(collected) == 0:
            collected = ["بازیکن ۱", "بازیکن ۲"]

        players.current = collected

        page.clean()

        main_content = ft.Column(
            [
                status_card,
                question_card,
                time_bar,
                ft.Row(
                    [
                        answer_input,
                        ft.ElevatedButton(
                            "✅ ثبت پاسخ",
                            on_click=check_answer,
                            bgcolor=ft.Colors.BLUE_600,
                            color=ft.Colors.WHITE,
                            icon=Icons.SEND,
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(radius=8),
                                padding=12
                            )
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=12,
                ),
                ft.Container(
                    result_text,
                    padding=15,
                    alignment=ft.alignment.center
                )
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=15,
        )

        page.add(
            ft.Container(
                content=ft.ListView(
                    [main_content],
                    padding=20,
                    spacing=0,
                    auto_scroll=False
                ),
                expand=True
            )
        )

        player_text.value = players.current[0]
        score_text.value = f"{score.current}"
        wrongs_text.value = f"{wrongs.current}/3"
        remaining_text.value = f"سوال: 0/10"

        reset_for_new_player()
        threading.Thread(target=run_timer, daemon=True).start()

    start_btn.on_click = start_game

    # صفحه شروع بازی مرحله‌ای
    start_column = ft.Column(
        [
            ft.Text("🎲 بازی مرحله‌ای احتمال",
                    size=26, weight=ft.FontWeight.BOLD,
                    color=ft.Colors.BLUE_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_200,
                    text_align=ft.TextAlign.CENTER),
            ft.Text("برای شروع، بازیکنان را اضافه کنید و روی دکمه شروع کلیک کنید",
                    size=16, color=ft.Colors.BLUE_600 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_400,
                    text_align=ft.TextAlign.CENTER),
            controls_start
        ],
        spacing=20,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )

    page.add(
        ft.Container(
            content=start_column,
            padding=20,
            alignment=ft.alignment.center
        )
    )

    # دو فیلد اولیه
    add_name_field()
    add_name_field()


# -------------------------
# بازی شبیه‌سازی سکه (بازی دوم)
# -------------------------
def coin_simulation_game(page: ft.Page):
    # پاک کردن کامل صفحه و ایجاد صفحه جدید
    page.clean()
    page.title = "🪙 شبیه‌سازی سکه"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.theme_mode = page.theme_mode  # حفظ حالت تاریک/روشن
    page.padding = 20

    # مراحل بازی
    stage = ft.Ref()
    stage.current = 1  # 1: سوال احتمال، 2: دریافت پیش‌بینی، 3: نمایش نتایج

    user_prob_prediction = ft.Ref()
    user_count_prediction = ft.Ref()
    total_flips = ft.Ref()
    actual_results = ft.Ref()

    user_prob_prediction.current = ""
    user_count_prediction.current = ""
    total_flips.current = 0
    actual_results.current = {"پشت": 0, "رو": 0}

    # المان‌های UI
    question_text = ft.Text(
        size=22,
        text_align=ft.TextAlign.CENTER,
        color=ft.Colors.BROWN_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BROWN_200,
        weight=ft.FontWeight.BOLD
    )

    result_text = ft.Text(
        size=18,
        text_align=ft.TextAlign.CENTER,
        color=ft.Colors.BROWN_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BROWN_300
    )

    input_field = ft.TextField(
        width=300,
        text_align=ft.TextAlign.CENTER,
        border_color=ft.Colors.ORANGE_400
    )

    submit_btn = ft.ElevatedButton(
        "تأیید",
        bgcolor=ft.Colors.ORANGE_600,
        color=ft.Colors.WHITE,
        icon=Icons.CHECK
    )

    back_btn = ft.ElevatedButton(
        "🔙 بازگشت به منو",
        on_click=lambda e: main_menu(page),
        bgcolor=ft.Colors.BLUE_600,
        color=ft.Colors.WHITE,
        icon=Icons.ARROW_BACK
    )

    # تابع شبیه‌سازی پرتاب سکه
    def simulate_coin_flips(num_flips):
        results = {"پشت": 0, "رو": 0}
        for _ in range(num_flips):
            if random.random() < 0.5:  # احتمال 50% برای پشت
                results["پشت"] += 1
            else:
                results["رو"] += 1
        return results

    # تابع بررسی پاسخ
    def check_answer(e):
        if stage.current == 1:
            # بررسی پاسخ احتمال
            user_answer = normalize_answer(input_field.value.strip())
            if user_answer == "1/2":
                user_prob_prediction.current = user_answer
                result_text.value = "🎉 درست است! احتمال پشت آمدن سکه 1/2 است."
                result_text.color = ft.Colors.GREEN_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREEN_300
                stage.current = 2
                update_stage()
            else:
                result_text.value = "❌ پاسخ صحیح 1/2 است. دوباره تلاش کن!"
                result_text.color = ft.Colors.RED_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.RED_300
                input_field.value = ""
                page.update()
                return

        elif stage.current == 2:
            # دریافت تعداد پرتاب‌ها و پیش‌بینی
            try:
                total_flips.current = int(input_field.value)
                if total_flips.current <= 0:
                    result_text.value = "❌ تعداد باید بزرگتر از صفر باشد!"
                    result_text.color = ft.Colors.RED_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.RED_300
                    page.update()
                    return
                if total_flips.current > 10000:
                    result_text.value = "❌ تعداد پرتاب‌ها نباید بیشتر از 10000 باشد!"
                    result_text.color = ft.Colors.RED_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.RED_300
                    page.update()
                    return

                result_text.value = f"عالی! حالا فکر می‌کنی از {total_flips.current} بار پرتاب، چند بار پشت می‌آید؟"
                result_text.color = ft.Colors.BROWN_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BROWN_300
                input_field.value = ""
                input_field.label = f"پیش‌بینی تعداد پشت (بین 0 تا {total_flips.current})"
                stage.current = 3
                update_stage()
            except ValueError:
                result_text.value = "❌ لطفاً یک عدد وارد کن!"
                result_text.color = ft.Colors.RED_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.RED_300
                page.update()

        elif stage.current == 3:
            # دریافت پیش‌بینی و نمایش نتایج
            try:
                user_prediction = int(input_field.value)
                if user_prediction < 0 or user_prediction > total_flips.current:
                    result_text.value = f"❌ پیش‌بینی باید بین 0 تا {total_flips.current} باشد!"
                    result_text.color = ft.Colors.RED_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.RED_300
                    page.update()
                    return

                user_count_prediction.current = user_prediction

                # شبیه‌سازی پرتاب سکه
                result_text.value = "🪙 در حال پرتاب سکه... لطفاً صبر کن!"
                result_text.color = ft.Colors.ORANGE_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.ORANGE_300
                page.update()

                # شبیه‌سازی با تأخیر برای ایجاد هیجان
                time.sleep(1.5)

                actual_results.current = simulate_coin_flips(total_flips.current)
                actual_backs = actual_results.current["پشت"]

                # نمایش نتایج
                accuracy = abs(actual_backs - user_prediction) / total_flips.current * 100
                accuracy_percent = 100 - accuracy

                result_text.value = (
                    f"🎊 نتایج شبیه‌سازی:\n\n"
                    f"🪙 تعداد پرتاب‌ها: {total_flips.current}\n"
                    f"📊 پیش‌بینی تو: {user_prediction} بار پشت\n"
                    f"🎯 نتیجه واقعی: {actual_backs} بار پشت\n"
                    f"✅ دقت پیش‌بینی: {accuracy_percent:.1f}%\n\n"
                    f"پشت: {actual_backs} بار - رو: {actual_results.current['رو']} بار"
                )
                result_text.color = ft.Colors.GREEN_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREEN_300

                stage.current = 4
                update_stage()

            except ValueError:
                result_text.value = "❌ لطفاً یک عدد وارد کن!"
                result_text.color = ft.Colors.RED_700 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.RED_300
                page.update()

    # تابع به‌روزرسانی مرحله
    def update_stage():
        if stage.current == 1:
            question_text.value = "سوال اول: احتمال پشت آمدن یک سکه چقدر است؟"
            input_field.label = "پاسخ (مثلاً 1/2 یا 0.5)"
            input_field.value = ""
            submit_btn.text = "بررسی پاسخ"
            input_field.visible = True
            submit_btn.visible = True

        elif stage.current == 2:
            question_text.value = "حالا می‌خواهیم سکه را چند بار پرتاب کنیم. چند بار می‌خواهی سکه پرتاب شود؟"
            input_field.label = "تعداد پرتاب‌ها (مثلاً 100)"
            input_field.value = ""
            submit_btn.text = "ادامه"
            input_field.visible = True
            submit_btn.visible = True

        elif stage.current == 3:
            question_text.value = f"پیش‌بینی تو برای تعداد پشت از {total_flips.current} بار پرتاب:"
            input_field.label = f"تعداد پشت پیش‌بینی شده"
            input_field.value = ""
            submit_btn.text = "شبیه‌سازی"
            input_field.visible = True
            submit_btn.visible = True

        elif stage.current == 4:
            question_text.value = "شبیه‌سازی انجام شد!"
            input_field.visible = False
            submit_btn.visible = False

        page.update()

    submit_btn.on_click = check_answer
    input_field.on_submit = check_answer

    # شروع بازی
    def start_simulation():
        stage.current = 1
        user_prob_prediction.current = ""
        user_count_prediction.current = ""
        total_flips.current = 0
        actual_results.current = {"پشت": 0, "رو": 0}
        input_field.visible = True
        submit_btn.visible = True
        update_stage()

    # رابط کاربری اصلی
    main_card = ft.Card(
        content=ft.Container(
            ft.Column(
                [
                    ft.Icon(Icons.ATTACH_MONEY, size=50, color=ft.Colors.ORANGE_600),
                    question_text,
                    input_field,
                    submit_btn,
                    ft.Container(result_text, padding=15),
                    ft.Row([
                        ft.ElevatedButton(
                            "🔄 بازی مجدد",
                            on_click=lambda e: start_simulation(),
                            bgcolor=ft.Colors.GREEN_600,
                            color=ft.Colors.WHITE,
                            icon=Icons.REPLAY
                        ),
                        back_btn
                    ], spacing=20, alignment=ft.MainAxisAlignment.CENTER)
                ],
                spacing=20,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=30,
            width=600,
        ),
        elevation=8,
        color=ft.Colors.WHITE if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREY_800,
    )

    page.add(
        ft.Column(
            [
                ft.Text("🪙 شبیه‌سازی احتمال سکه",
                        size=28, weight=ft.FontWeight.BOLD,
                        color=ft.Colors.BROWN_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BROWN_200),
                ft.Text("بیا با هم سکه پرتاب کنیم و پیش‌بینی‌هایت را آزمایش کن!",
                        size=16,
                        color=ft.Colors.BROWN_600 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BROWN_400),
                main_card
            ],
            spacing=25,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
    )

    start_simulation()


# -------------------------
# منوی اصلی
# -------------------------
def main_menu(page: ft.Page):
    page.clean()
    page.title = "🎮 مجموعه بازی‌های احتمال"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.theme_mode = page.theme_mode  # حفظ حالت تاریک/روشن
    page.padding = 40

    # دکمه تغییر حالت تاریک/روشن
    def toggle_theme(e):
        page.theme_mode = ft.ThemeMode.DARK if page.theme_mode == ft.ThemeMode.LIGHT else ft.ThemeMode.LIGHT
        theme_btn.icon = Icons.DARK_MODE if page.theme_mode == ft.ThemeMode.LIGHT else Icons.LIGHT_MODE
        theme_btn.text = "حالت تاریک" if page.theme_mode == ft.ThemeMode.LIGHT else "حالت روشن"
        page.update()
        # بازخوانی منوی اصلی برای اعمال تغییرات رنگ
        main_menu(page)

    theme_btn = ft.ElevatedButton(
        content=ft.Row([
            ft.Icon(Icons.DARK_MODE if page.theme_mode == ft.ThemeMode.LIGHT else Icons.LIGHT_MODE),
            ft.Text("حالت تاریک" if page.theme_mode == ft.ThemeMode.LIGHT else "حالت روشن")
        ]),
        on_click=toggle_theme,
        bgcolor=ft.Colors.GREY_600 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREY_800,
        color=ft.Colors.WHITE,
    )

    # کارت بازی مرحله‌ای
    stage_game_card = ft.Card(
        content=ft.Container(
            ft.Column(
                [
                    ft.Icon(Icons.STAR, size=60, color=ft.Colors.AMBER_600),
                    ft.Text("بازی مرحله‌ای احتمال", size=24, weight=ft.FontWeight.BOLD,
                            color=ft.Colors.BLUE_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_200),
                    ft.Text("• سوالات متنوع احتمال\n• سطح‌بندی شده\n• چند بازیکنه\n• محدودیت زمان",
                            size=16,
                            color=ft.Colors.BLUE_600 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_400),
                    ft.ElevatedButton(
                        "شروع بازی",
                        on_click=lambda e: stage_game(page),
                        bgcolor=ft.Colors.BLUE_600,
                        color=ft.Colors.WHITE,
                        icon=Icons.PLAY_ARROW,
                        style=ft.ButtonStyle(padding=20, shape=ft.RoundedRectangleBorder(radius=12))
                    )
                ],
                spacing=20,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=30,
            width=300,
        ),
        elevation=10,
        margin=10,
        color=ft.Colors.WHITE if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREY_800,
    )

    # کارت شبیه‌سازی سکه
    simulation_card = ft.Card(
        content=ft.Container(
            ft.Column(
                [
                    ft.Icon(Icons.ATTACH_MONEY, size=60, color=ft.Colors.ORANGE_600),
                    ft.Text("شبیه‌سازی سکه", size=24, weight=ft.FontWeight.BOLD,
                            color=ft.Colors.ORANGE_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.ORANGE_200),
                    ft.Text("• آزمایش پیش‌بینی‌ها\n• شبیه‌سازی واقعی\n• مقایسه نتایج\n• آموزشی و سرگرم کننده",
                            size=16,
                            color=ft.Colors.ORANGE_600 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.ORANGE_400),
                    ft.ElevatedButton(
                        "شروع بازی",
                        on_click=lambda e: coin_simulation_game(page),
                        bgcolor=ft.Colors.ORANGE_600,
                        color=ft.Colors.WHITE,
                        icon=Icons.PLAY_ARROW,
                        style=ft.ButtonStyle(padding=20, shape=ft.RoundedRectangleBorder(radius=12))
                    )
                ],
                spacing=20,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=30,
            width=300,
        ),
        elevation=10,
        margin=10,
        color=ft.Colors.WHITE if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREY_800,
    )

    # کارت مارپله
    snake_ladder_card = ft.Card(
        content=ft.Container(
            ft.Column(
                [
                    ft.Icon(Icons.CASINO, size=60, color=ft.Colors.GREEN_600),
                    ft.Text("مارپله احتمال", size=24, weight=ft.FontWeight.BOLD,
                            color=ft.Colors.GREEN_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREEN_200),
                    ft.Text("• ترکیب مارپله و احتمال\n• سوالات جذاب\n• حرکت با تاس\n• مارها و نردبان‌ها",
                            size=16,
                            color=ft.Colors.GREEN_600 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREEN_400),
                    ft.ElevatedButton(
                        "شروع بازی",
                        on_click=lambda e: snake_ladder_game(page),
                        bgcolor=ft.Colors.GREEN_600,
                        color=ft.Colors.WHITE,
                        icon=Icons.PLAY_ARROW,
                        style=ft.ButtonStyle(padding=20, shape=ft.RoundedRectangleBorder(radius=12))
                    )
                ],
                spacing=20,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=30,
            width=300,
        ),
        elevation=10,
        margin=10,
        color=ft.Colors.WHITE if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.GREY_800,
    )

    page.add(
        ft.Column(
            [
                ft.Row([
                    theme_btn
                ], alignment=ft.MainAxisAlignment.END),

                ft.Text("🎮 مجموعه بازی‌های احتمال",
                        size=32, weight=ft.FontWeight.BOLD,
                        color=ft.Colors.BLUE_800 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_200),
                ft.Text("برای پایه‌های هفتم تا نهم",
                        size=18,
                        color=ft.Colors.BLUE_600 if page.theme_mode == ft.ThemeMode.LIGHT else ft.Colors.BLUE_400),
                ft.Row(
                    [stage_game_card, simulation_card, snake_ladder_card],
                    alignment=ft.MainAxisAlignment.CENTER,
                    spacing=20,
                    wrap=True
                )
            ],
            spacing=40,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
    )


# -------------------------
# تابع اصلی
# -------------------------
def main(page: ft.Page):
    # راه‌اندازی اولیه
    page.theme_mode = ft.ThemeMode.LIGHT

    # تنظیمات پنجره
    page.window.width = 1200
    page.window.height = 800
    page.window.min_width = 800
    page.window.min_height = 600
    page.title = "Probability Games - مجموعه بازی‌های احتمال"

    main_menu(page)


# برای اجرای مستقیم
if __name__ == "__main__":
    ft.app(target=main, view=ft.WEB_BROWSER)